import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { AuthResponse } from './auth-response.model';
import { AuthRequest } from './auth-request.model';
import { TokenService } from './token.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})

export class AuthService {

  public $userIsLoggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);


  constructor(private http: HttpClient, private tokenService: TokenService, private router: Router) { }

  public login(authRequest: AuthRequest): Observable<AuthResponse> {
    return this.http
    .post<AuthResponse>('http://localhost:8080/api/auth/login', authRequest)
    .pipe(
      tap((authResponse: AuthResponse) => {
        this.tokenService.storeToken(authResponse.token)
      })
    );
  }

  public register(authRequest: AuthRequest): Observable<AuthResponse> {
    return this.http
    .post<AuthResponse>('http://localhost:8080/api/auth/register', authRequest)
    .pipe(
      tap((authResponse: AuthResponse) => {
        this.tokenService.storeToken(authResponse.token)
      })
    );
  }

  public logOut(): void{
    this.tokenService.dropToken();
    this.$userIsLoggedIn.next(false);
  }


  navigateToHome() {
    this.router.navigate(['/Home'])
  }

}
