import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { AuthResponse } from '../auth-response.model';
import { TokenService } from '../token.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})

export class LoginComponent implements OnInit {

  public loginForm: FormGroup;
  public isLoggedIn: boolean = false;

  constructor(private fb: FormBuilder, private authService: AuthService, private tokenService: TokenService) {

  }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.email, Validators.required]],
      password: ['', [Validators.required, Validators.minLength(8)]]
    })
  }

  public onSubmit(): void {
    this.authService
    .login(this.loginForm.value)
    .subscribe((authResponse: AuthResponse) => {
      console.log("hoera er is een token binnen");
      console.log(authResponse);
      location.reload();      
    })
    this.navigateToHome();
  }

  public navigateToHome() {
    this.authService.navigateToHome();
  }
}
