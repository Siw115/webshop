export class JwtPayload {
    public sub: string;
    public email: string;
    public exp: number;
    public iat: number;
}
