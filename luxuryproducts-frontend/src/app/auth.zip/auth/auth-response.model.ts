export class AuthResponse {
    public email: string;
    public token: string;
}
