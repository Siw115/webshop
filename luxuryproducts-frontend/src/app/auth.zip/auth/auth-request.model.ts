export class AuthRequest {
    public email: string;
    public password: string;
}
