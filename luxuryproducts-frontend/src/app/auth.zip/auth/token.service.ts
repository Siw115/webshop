import { Injectable } from '@angular/core';
import { JwtPayload } from './jwt-payload.model';

@Injectable({
  providedIn: 'root'
})
export class TokenService {

  constructor() { }

  public storeToken(token: string) {
    localStorage.setItem('token', token)
  }

  public loadToken(): string {
    return localStorage.getItem('token')
  }

  public dropToken(): void {
    localStorage.removeItem('token')
  }

  private getPayload(token: string): JwtPayload {
    const jwtPayload = token.split('.')[1];
    return JSON.parse(atob(jwtPayload))
  }

  private tokenExpired(token: string): boolean {
    const expiry = this.getPayload(token).exp;
    return (Math.floor((new Date).getTime() / 1000)) >= expiry;
  }

  public isValid(): boolean {
    const token: string = this.loadToken();
    
    if(this.tokenExpired(token)) {
      return false;
    }

    return true;
  }
}
